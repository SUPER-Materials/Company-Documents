<!-- Nén code HTML -->
<?php
function sanitize_output($buffer) {
    $search = array(
        '/\>[^\S ]+/s',     // Xoá khoảng trắng sau tag
        '/[^\S ]+\</s',     // Xoá khoảng trắng trước tag
        '/(\s)+/s',         // Rút ngắn chuỗi khoảng trắng
        '/<!--(.|\s)*?-->/' // Xoá comments
    );
    $replace = array(
        '>',
        '<',
        '\\1',
        ''
    );
    $buffer = preg_replace($search, $replace, $buffer);
    return $buffer;
}
ob_start("sanitize_output");
?>
<!-- /Nén code HTML -->

<!-- Canonical -->
function getCurrentPageURL() {
    global $_SERVER;
    $pageURL = 'http';
    if(isset($_SERVER["HTTPS"]))
    if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
    $pageURL .= "://";
    if ($_SERVER["SERVER_PORT"] != "80") {
        $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
    } else {
        $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
    }
    $pageURL = explode("/page/", $pageURL);
    return $pageURL[0];
}
<!-- /Canonical -->
